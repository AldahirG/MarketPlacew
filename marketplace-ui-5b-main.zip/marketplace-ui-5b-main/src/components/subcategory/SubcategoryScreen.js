import React from "react";

export const SubcategoryScreen = () => {
  return <div>SubcategoryScreen</div>;
};
