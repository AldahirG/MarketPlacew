import React from 'react'

export default function HomeScreen() {
  return (
    <div>HomeScreen</div>
  )
}
